# SafeSMS API

Standalone Node.js + Express SMS/OTP backend with strict anti-abuse limits.

## 1. Install

```bash
npm install
```

## 2. PostgreSQL

Create a database, then run:

```bash
psql "$DATABASE_URL" -f db/schema.sql
```

## 3. Configure

Copy `.env.example` to `.env`.

Start with:

```env
SMS_DRY_RUN=true
```

This lets you test the API without sending real SMS.

For real SMS, configure a Twilio account and set:

```env
SMS_DRY_RUN=false
TWILIO_ACCOUNT_SID=...
TWILIO_AUTH_TOKEN=...
TWILIO_FROM_NUMBER=...
```

Never commit `.env` to Git.

## 4. Run

```bash
npm start
```

Open `http://localhost:3000`.

## API

`POST /api/sms/send`
```json
{"phone":"+919876543210","message":"Hello"}
```

`POST /api/otp/send`
```json
{"phone":"+919876543210"}
```

`POST /api/otp/verify`
```json
{"phone":"+919876543210","code":"123456"}
```

## Limits

- 1 SMS/OTP per phone per 60 seconds
- 5 per phone per hour
- 10 per IP per hour
- 20 per IP per day
- OTP expires in 5 minutes
- Maximum 5 OTP verification attempts

For production, add authentication, CAPTCHA/consent controls, provider webhooks, Redis-based distributed rate limiting, monitoring, and a formal abuse/opt-out workflow.
