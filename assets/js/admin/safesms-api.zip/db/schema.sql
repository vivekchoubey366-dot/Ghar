CREATE TABLE IF NOT EXISTS sms_messages (
  id BIGSERIAL PRIMARY KEY,
  phone_e164 VARCHAR(20) NOT NULL,
  message TEXT NOT NULL,
  provider VARCHAR(40) NOT NULL DEFAULT 'twilio',
  provider_message_id VARCHAR(100),
  status VARCHAR(30) NOT NULL DEFAULT 'queued',
  ip_hash VARCHAR(128),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_sms_phone_created
  ON sms_messages(phone_e164, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_sms_ip_created
  ON sms_messages(ip_hash, created_at DESC);

CREATE TABLE IF NOT EXISTS otp_codes (
  id BIGSERIAL PRIMARY KEY,
  phone_e164 VARCHAR(20) NOT NULL,
  code_hash CHAR(64) NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  expires_at TIMESTAMPTZ NOT NULL,
  verified_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_otp_phone_created
  ON otp_codes(phone_e164, created_at DESC);
