import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import crypto from "crypto";
import { Pool } from "pg";
import twilio from "twilio";
import path from "path";
import { fileURLToPath } from "url";

dotenv.config();

const app = express();
const port = Number(process.env.PORT || 3000);
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(cors({
  origin: process.env.CORS_ORIGIN || `http://localhost:${port}`,
  credentials: false
}));
app.use(express.json({ limit: "10kb" }));
app.use(express.static(path.join(__dirname, "public")));

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const LIMITS = {
  perNumberMinute: 1,
  perNumberHour: 5,
  perIpHour: 10,
  perIpDay: 20
};

function normalizePhone(value) {
  return String(value || "").replace(/[^\d+]/g, "");
}

function validPhone(phone) {
  return /^\+[1-9]\d{9,14}$/.test(phone);
}

function hashIp(ip) {
  return crypto.createHash("sha256").update(String(ip)).digest("hex");
}

function hashCode(code) {
  return crypto.createHash("sha256").update(String(code)).digest("hex");
}

function randomOtp() {
  return String(crypto.randomInt(100000, 1000000));
}

async function countSince(field, value, since) {
  const q = field === "phone_e164"
    ? `SELECT COUNT(*)::int AS count FROM sms_messages WHERE phone_e164=$1 AND created_at >= $2`
    : `SELECT COUNT(*)::int AS count FROM sms_messages WHERE ip_hash=$1 AND created_at >= $2`;
  const r = await pool.query(q, [value, since]);
  return r.rows[0].count;
}

async function checkLimits(phone, ipHash) {
  const now = Date.now();
  const minute = new Date(now - 60_000);
  const hour = new Date(now - 3_600_000);
  const day = new Date(new Date().setHours(0,0,0,0));

  const [pm, ph, ih, id] = await Promise.all([
    countSince("phone_e164", phone, minute),
    countSince("phone_e164", phone, hour),
    countSince("ip_hash", ipHash, hour),
    countSince("ip_hash", ipHash, day)
  ]);

  if (pm >= LIMITS.perNumberMinute) return "Phone cooldown: try again after 60 seconds.";
  if (ph >= LIMITS.perNumberHour) return "Phone hourly limit reached.";
  if (ih >= LIMITS.perIpHour) return "IP hourly limit reached.";
  if (id >= LIMITS.perIpDay) return "IP daily limit reached.";
  return null;
}

async function sendProviderSms(phone, message) {
  if (String(process.env.SMS_DRY_RUN).toLowerCase() === "true") {
    return { sid: null, status: "dry_run" };
  }

  const client = twilio(
    process.env.TWILIO_ACCOUNT_SID,
    process.env.TWILIO_AUTH_TOKEN
  );

  const result = await client.messages.create({
    body: message,
    from: process.env.TWILIO_FROM_NUMBER,
    to: phone
  });

  return { sid: result.sid, status: result.status || "queued" };
}

app.get("/api/health", async (_req, res) => {
  try {
    await pool.query("SELECT 1");
    res.json({ ok: true, database: true, smsDryRun: String(process.env.SMS_DRY_RUN).toLowerCase() === "true" });
  } catch {
    res.status(503).json({ ok: false, database: false });
  }
});

app.post("/api/sms/send", async (req, res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const message = String(req.body.message || "").trim();
    const ip = hashIp(req.ip);

    if (!validPhone(phone)) return res.status(400).json({ error: "Use E.164 format, e.g. +919876543210." });
    if (!message || message.length > 160) return res.status(400).json({ error: "Message must be 1-160 characters." });

    const limitError = await checkLimits(phone, ip);
    if (limitError) return res.status(429).json({ error: limitError });

    const provider = await sendProviderSms(phone, message);

    const saved = await pool.query(
      `INSERT INTO sms_messages
       (phone_e164,message,provider,provider_message_id,status,ip_hash)
       VALUES ($1,$2,'twilio',$3,$4,$5)
       RETURNING id, status, created_at`,
      [phone, message, provider.sid, provider.status, ip]
    );

    res.status(202).json({
      ok: true,
      messageId: saved.rows[0].id,
      providerStatus: saved.rows[0].status,
      dryRun: String(process.env.SMS_DRY_RUN).toLowerCase() === "true"
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "SMS service error." });
  }
});

app.post("/api/otp/send", async (req, res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const ip = hashIp(req.ip);
    if (!validPhone(phone)) return res.status(400).json({ error: "Use E.164 format." });

    const limitError = await checkLimits(phone, ip);
    if (limitError) return res.status(429).json({ error: limitError });

    const code = randomOtp();
    const expires = new Date(Date.now() + 5 * 60_000);
    const codeHash = hashCode(code);

    await pool.query(
      `INSERT INTO otp_codes(phone_e164,code_hash,expires_at) VALUES($1,$2,$3)`,
      [phone, codeHash, expires]
    );

    const message = `Your verification code is ${code}. It expires in 5 minutes.`;
    const provider = await sendProviderSms(phone, message);

    await pool.query(
      `INSERT INTO sms_messages
       (phone_e164,message,provider,provider_message_id,status,ip_hash)
       VALUES ($1,$2,'twilio',$3,$4,$5)`,
      [phone, message, provider.sid, provider.status, ip]
    );

    res.status(202).json({
      ok: true,
      expiresInSeconds: 300,
      dryRun: String(process.env.SMS_DRY_RUN).toLowerCase() === "true",
      demoCode: String(process.env.SMS_DRY_RUN).toLowerCase() === "true" ? code : undefined
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "OTP service error." });
  }
});

app.post("/api/otp/verify", async (req, res) => {
  try {
    const phone = normalizePhone(req.body.phone);
    const code = String(req.body.code || "").trim();
    if (!validPhone(phone) || !/^\d{6}$/.test(code))
      return res.status(400).json({ error: "Invalid phone or OTP." });

    const r = await pool.query(
      `SELECT * FROM otp_codes
       WHERE phone_e164=$1 AND verified_at IS NULL
       ORDER BY created_at DESC LIMIT 1`,
      [phone]
    );

    if (!r.rows.length) return res.status(400).json({ error: "No active OTP." });

    const otp = r.rows[0];
    if (new Date(otp.expires_at) < new Date()) return res.status(400).json({ error: "OTP expired." });
    if (otp.attempts >= 5) return res.status(429).json({ error: "Too many verification attempts." });

    await pool.query(`UPDATE otp_codes SET attempts=attempts+1 WHERE id=$1`, [otp.id]);

    if (hashCode(code) !== otp.code_hash)
      return res.status(400).json({ error: "Incorrect OTP." });

    await pool.query(`UPDATE otp_codes SET verified_at=NOW() WHERE id=$1`, [otp.id]);
    res.json({ ok: true, verified: true });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "OTP verification error." });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => console.log(`SafeSMS API running on http://localhost:${port}`));
